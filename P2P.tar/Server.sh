#!/bin/bash
java -cp bin csc573.common.Start server

