#!/bin/bash
javac -verbose -d bin $(find . -name "*.java")

